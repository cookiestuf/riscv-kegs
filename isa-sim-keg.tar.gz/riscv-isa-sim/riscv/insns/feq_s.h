require_extension('F');
require_fp;
WRITE_RD(f32_eq(f32(FRS1), f32(FRS2)));
set_fp_exceptions;
