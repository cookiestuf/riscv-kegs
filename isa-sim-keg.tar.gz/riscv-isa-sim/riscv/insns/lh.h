WRITE_RD(MMU.load_int16(RS1 + insn.i_imm()));
