require_extension('C');
set_pc(pc + insn.rvc_j_imm());
