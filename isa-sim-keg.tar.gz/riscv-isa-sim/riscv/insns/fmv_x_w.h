require_extension('F');
require_fp;
WRITE_RD(sext32(FRS1.v[0]));
